var crc = require('crc');
var serialport = require("serialport");
var SerialPort = serialport.SerialPort; // localize object constructor

// connect to the serial port of the "stick"
var sp = new SerialPort("/dev/tty.usbserial-A8005W6k", { 
    baudrate: 115200,
    parser: serialport.parsers.readline("\n") 
});

// read incoming data
sp.on("data", function (data) {
    var result = data;

    // sometimes the first character is unreadable, so we remove it (might be wrong)
    if (unicodeEscape(result[0]) == '\\ufffd') {
        data = data.substring(1);
    }
    //console.log("here: "+data);
});

// found this code to check for special characters
function unicodeEscape(str) {
    return str.replace(/[\s\S]/g, function(character) {
        var escape = character.charCodeAt().toString(16),
            longhand = escape.length > 2;
        return '\\' + (longhand ? 'u' : 'x') + ('0000' + escape).slice(longhand ? -4 : -2);
    });
}

// some basic protocol data
var protocolData = {
    startFrame: '\x05\x05\x03\x03',
    init: '000A',
    powerUsage: '0012',
    switch: '0017',
    endFrame: '\r'
}

// a basic object to gather everything
var plugwise = {};

// builds the command string and sends it
function sendCommand(command, mac, params) {
    var completeCommand = '';
    completeCommand += command;
    if (mac) {
        completeCommand += mac;
    }

    if (params) {
        completeCommand += params;
    }

    completeCommand += crc.crc16(completeCommand).toString(16).toUpperCase();
    completeCommand = protocolData.startFrame + completeCommand + protocolData.endFrame;
    //console.log("command", completeCommand);
    sp.write(completeCommand);
    return completeCommand;
}


// the init command, has to be called first
plugwise.init = function() {
    console.log('Init plugwise');
    var command = sendCommand(protocolData.init);
}

// get the power usage of an appliance. the result has to be parsed later
function getPowerUsage(mac) {
    var command = sendCommand(protocolData.powerUsage, mac);
}

// turn on anappliance
function turnOn(appliance) {
    console.log('Switching on ' + appliance.name);
    sendCommand(protocolData.switch, appliance.mac, '01');
}

// gues what this does
function turnOff(appliance) {
    console.log('Switching off ' + appliance.name);
    sendCommand(protocolData.switch, appliance.mac, '00');
}

// list of my appliances
var appliances = {
    espressoMachine: {
        mac: '000D6F0000Dxxxxx', // mac address of circle controlling the espresso machine
        name: "Espresso Machine"
    },
    lampInSmallRoom: {
        mac: '000D6F0001Axxxxx', // mac address of circle controlling the small lamp
        name: 'Lamp in small room'
    }
}

// example:
// init, turn the machine off, then wait 5 secs and turn it on.
plugwise.init();

setTimeout(function(){
    turnOff(appliances.espressoMachine); 
}, 1000);

setTimeout(function(){
    turnOn(appliances.espressoMachine); 
    process.exit();
}, 5000);

